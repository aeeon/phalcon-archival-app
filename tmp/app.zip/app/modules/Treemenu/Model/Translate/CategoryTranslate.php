<?php

namespace Treemenu\Model\Translate;

use Application\Mvc\Model\Translate;

class CategoryTranslate extends Translate
{

    public function getSource()
    {
        return "menu_translate";
    }

}