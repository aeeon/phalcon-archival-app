<?php

namespace Application\Widget;

use Application\Widget\AbstractWidget;
use Menu\Item;

class ApplicationWidget extends AbstractWidget {

    public function buildMenu($name, $template) {
        $tree = [];
        $entries = \Treemenu\Model\Category::find(array(
                    "conditions" => "root = '{$name}' AND depth = '1'",
                    "order" => "left_key",
        ));
        $i = 0;
        foreach ($entries as $entry) {
            $data = json_decode($entry->data);
            $url = $this->getUrlByData($data);

            $tree[$i]['entry'] = $this->getMenuObject($url, $entry, $data);

            $subentries = \Treemenu\Model\Category::find(array(
                        "conditions" => "depth = '2' AND root = '{$name}' AND parent_id = '{$entry->getId()}'",
                        "order" => "left_key",
            ));
            if (!empty($subentries)) {

                foreach ($subentries as $subentry) {
                    $suburl = "";
                    if (false and $subentry->auto == 1) {
                        die('test');
                    } else {

                        $subchilds = \Treemenu\Model\Category::find(array(
                                    "conditions" => "depth = '3' AND root = '{$name}' AND parent_id = '{$subentry->getId()}'",
                                    "order" => "left_key",
                        ));
                        $data = json_decode($subentry->data);
                        if (empty($url)) {
                            $suburl = $this->getUrlByData($data);
                        } else {
                            $suburl = $this->getUrlByData($data);
                            if (!empty($suburl))
                                $suburl = $url . "/" . $suburl;
                        }
                        $obj = $this->getMenuObject($suburl, $subentry);

                        $childs = array();
                        foreach ($subchilds as $child) {
                            $child_data = json_decode($child->data);

                            $child_url = $this->getUrlByData($child_data);

                            if (!empty($child_url))
                                $child_url = $suburl . "/" . $child_url;
                            $childs[] = $this->getMenuObject($child_url, $child);
                        }

                        $tree[$i]['subentries'][] = array("entry" => $obj, "childs" => $childs);
                    }
                }
            } else {
                $tree[$i]['subentries'] = array();
            }
            $i++;
        }
        $this->widgetPartial($template, ['entries' => $tree]);
    }

    public function sidebarMenu($type_id, $name, $template) {
        $tree = [];

        $entries = \Treemenu\Model\Category::find(array(
                    "conditions" => "root = '{$name}' AND depth = '1'",
                    "order" => "left_key",
        ));

        $id = 0;
        $url="";

        foreach ($entries as $entry) {
            
            $data = json_decode($entry->data);
             
            if ($data->item_id == $type_id && $data->type == 'type') {
                $url = $this->getUrlByData($data);
                $id = $entry->getId();
              
            }
        }
     
        $subentries = \Treemenu\Model\Category::find(array(
                    "conditions" => "depth = '2' AND root = '{$name}' AND parent_id = '{$id}'",
                    "order" => "left_key",
        ));
                             
        if (!empty($subentries)) {


            foreach ($subentries as $subentry) {
                  
                $suburl = "";
                if (false and $subentry->auto == 1) {
                    die('test');
                } else {

                    $subchilds = \Treemenu\Model\Category::find(array(
                                "conditions" => "depth = '3' AND root = '{$name}' AND parent_id = '{$subentry->getId()}'",
                                "order" => "left_key",
                    ));
                                
                    $data = json_decode($subentry->data);
                    if (empty($url)) {
                        $suburl = $this->getUrlByData($data);
                    } else {
                        $suburl = $this->getUrlByData($data);
                        if (!empty($suburl))
                            $suburl = $url . "/" . $suburl;
                    }
                    $obj = $this->getMenuObject($suburl, $subentry);

                    $childs = array();
                    foreach ($subchilds as $child) {
                          
                        $child_data = json_decode($child->data);

                        $child_url = $this->getUrlByData($child_data);

                        if (!empty($child_url))
                            $child_url = $suburl . "/" . $child_url;
                        $childs[] = $this->getMenuObject($child_url, $child);
                    }

                    $tree[] = array("entry" => $obj, "childs" => $childs);
                }
            }
        } else {
            $tree = array();
        }

        $this->widgetPartial($template, ['entries' => $tree]);
    }

    private function getMenuObject($url, $entry, $data=null) {
        $obj = new \stdClass();
        if (empty($url)) {
            $obj->url = "javascript:void(0)";
        } else
            $obj->url = $this->config->base_path . $url;

        $obj->title = $entry->getTitle();
        $obj->newwindow = $entry->getNewwindow();
        $obj->custom = $entry->getCustom();
        $obj->auto = $entry->getAuto();
        $obj->status = $entry->getStatus();
        
        $obj->type = $data->item_id;
        $obj->typ = $data->type;
        return $obj;
    }

    private function getUrlByData($data) {
        if ($data->type == 'category') {
            $item = \Tree\Model\Category::findFirst("id='{$data->item_id}'");
            return $item->getSlug();
        } else if ($data->type == 'page') {
            $item = \Page\Model\Page::findFirst("id='{$data->item_id}'");
            return $item->getSlug() . ".html";
        } else if ($data->type == 'type') {
            $item = \Publication\Model\Type::findFirst("id='{$data->item_id}'");
            return $item->getSlug();
        } else {
            return null;
        }
    }

}
