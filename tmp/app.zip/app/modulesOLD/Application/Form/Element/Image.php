<?php
/**
 * @copyright Copyright (c) 2011 - 2015 Oleksandr Torosh (http://yonacms.com)
 * @author Oleksandr Torosh <webtorua@gmail.com>
 */

namespace Application\Form\Element;

class Image extends \Phalcon\Forms\Element\File
{

}