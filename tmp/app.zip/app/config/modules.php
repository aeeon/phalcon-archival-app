<?php

/**
 * Modules "Application" and "Cms" loads automatically
 * */

return array(
    'Image',
    'Index',
    'Admin',
    'Widget',
    'Porady',
    'Comment',
    'FileManager',
    'Page',
    'Publication',
    'Seo',
    'Menu',
    'Tree',
    'Sitemap',
    'Treemenu',
);